'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useCart } from '@/context/CartContext';
import {
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Button,
    Typography,
    Grid,
    CardMedia,
    Box,
    Paper,
    IconButton,
    Divider,
    Chip
} from '@mui/material';

import {
    ShoppingCart,
    X,
    ChevronLeft,
    ChevronRight,
    ScanSearch,
    Trash2,
    Maximize,
    Minimize,
    Scale,
    Gem,
    Layers,
    Tag,
    Hash
} from 'lucide-react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Keyboard, Mousewheel, Navigation, Virtual } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/navigation';
import ReusableConfirmModal from '../Common/ReusableConfirmModal';


export default function ProductModal({ open, onClose, product, products = [], startIndex = 0, onAddToCart, onSearchSimilar, fromCart, urlParamsFlag }) {
    const [activeIndex, setActiveIndex] = useState(startIndex);
    const { isItemInCart, removeFromCart } = useCart();
    const [openConfirmModal, setOpenConfirmModal] = useState(false);
    const [swiperRef, setSwiperRef] = useState(null);
    const [isFullscreen, setIsFullscreen] = useState(false);

    const softPrimaryButtonSx = {
        textTransform: 'none',
        boxShadow: 'none',
        borderRadius: 2,
        borderColor: 'transparent',
        bgcolor: 'rgba(115, 103, 240, 0.08)',
        color: 'primary.dark',
        '&:hover': {
            bgcolor: 'rgba(115, 103, 240, 0.12)',
            borderColor: 'transparent',
            boxShadow: 'none',
        },
    };

    const softDangerButtonSx = {
        textTransform: 'none',
        boxShadow: 'none',
        borderRadius: 2,
        borderColor: 'transparent',
        bgcolor: 'rgba(244, 67, 54, 0.08)',
        color: 'error.dark',
        '&:hover': {
            bgcolor: 'rgba(244, 67, 54, 0.12)',
            borderColor: 'transparent',
            boxShadow: 'none',
        },
    };

    const sliderButton = {
        width: 36,
        height: 36,
        borderRadius: '50%',
        backgroundColor: 'secondary.extraLight',
        color: 'secondary.dark',
        '&:hover': {
            bgcolor: 'secondary.extraLight',
            borderColor: 'transparent',
            boxShadow: 'none',
        },
    }

    // When modal opens, ensure slider starts from the provided startIndex
    useEffect(() => {
        if (open) {
            setActiveIndex(startIndex);
            if (swiperRef) {
                swiperRef.slideTo(startIndex, 0);
            }
        }
    }, [open, startIndex, swiperRef]);

    if (!product) return null;

    const sliderProducts = products.length > 0
        ? products.slice(0, 100)
        : Array(100).fill().map((_, i) => ({
            ...product,
            id: `${product.id || 'product'}-${i}`,
            thumbUrl: product.thumbUrl,
            originalUrl: product.originalUrl,
            image: product.thumbUrl || product.image || "/images/image-not-found.jpg",
            designno: `${product.designno || 'PROD'}-${i + 1}`
        }));

    const handleSlideChange = (swiper) => {
        setActiveIndex(swiper.activeIndex);
    };

    const handleRemoveItem = () => {
        setOpenConfirmModal(true);
    };

    const handleConfirmRemove = () => {
        const currentProduct = sliderProducts[activeIndex] || product;
        if (currentProduct) {
            removeFromCart(currentProduct.id);
        }
        setOpenConfirmModal(false);
        onClose();
    };

    const currentProd = sliderProducts[activeIndex] || product;

    return (
        <Dialog
            open={open}
            onClose={onClose}
            maxWidth={isFullscreen ? false : "lg"}
            fullWidth
            fullScreen={isFullscreen}
            PaperProps={{
                sx: {
                    height: isFullscreen ? '800px' : 'calc(90vh - 70px)',
                    maxHeight: isFullscreen ? '100%' : 'calc(90vh - 70px)',
                    borderRadius: isFullscreen ? 0 : 3,
                    m: isFullscreen ? 0 : 2
                }
            }}
            sx={{
                '& .MuiDialog-container': {
                    height: isFullscreen ? '100%' : '94%',
                    maxHeight: isFullscreen ? '100%' : '94%'
                }
            }}
        >
            <DialogTitle sx={{ m: 0, p: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center', bgcolor: 'background.paper', borderBottom: '1px solid', borderColor: 'divider' }}>
                <Typography variant="h6" fontWeight="bold">
                    Product Details
                </Typography>
                <Box sx={{ display: 'flex', gap: 1 }}>
                    <IconButton
                        onClick={() => setIsFullscreen(!isFullscreen)}
                        size="small"
                        sx={{ color: theme => theme.palette.grey[500], padding: 1 }}
                    >
                        {isFullscreen ? <Minimize size={20} /> : <Maximize size={20} />}
                    </IconButton>
                    <IconButton onClick={onClose} sx={{ color: theme => theme.palette.grey[500], padding: 1 }}>
                        <X size={20} />
                    </IconButton>
                </Box>
            </DialogTitle>

            <DialogContent sx={{ p: 0, overflow: 'hidden' }}>
                <Swiper
                    modules={[Virtual, Keyboard, Mousewheel]}
                    onSwiper={setSwiperRef}
                    spaceBetween={0}
                    slidesPerView={1}
                    keyboard={{ enabled: true }}
                    mousewheel={{ enabled: true }}
                    virtual={{ enabled: true }}
                    initialSlide={startIndex}
                    onSlideChange={handleSlideChange}
                    style={{ width: '100%', height: '100%' }}
                >
                    {sliderProducts.map((prod, index) => {
                        // Recalculate conditional flags per product
                        const pDiamonds = (prod.diamondpcs > 0) || (prod.diamondweight > 0);
                        const pStones = (prod.stonepcs > 0) || (prod.stoneweight > 0);
                        const pMetal = prod.metalcolor || prod.metalpurity || prod.metaltype;

                        // Check if we have any "additional" info to show
                        const hasAdditionalInfo = prod.categoryname || prod.subcategoryname || prod.collectionname || prod.producttype || prod.brandname || prod.stylename || prod.gendername;

                        return (
                            <SwiperSlide key={`${prod.id || 'product'}-${index}`} virtualIndex={index}>
                                <Grid container sx={{ height: '100%' }}>
                                    {/* Image Section - Priority (Cover + No Shadow) */}
                                    <Grid size={{ xs: 12, md: isFullscreen ? 9.5 : 8 }} sx={{ height: { xs: '50%', md: '100%' }, bgcolor: 'grey.50' }}>
                                        <Box sx={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                            <CardMedia
                                                component="img"
                                                image={prod.originalUrl || prod.image || prod.thumbUrl || "/images/image-not-found.jpg"}
                                                alt={prod.categoryname || 'Product image'}
                                                sx={{
                                                    objectFit: 'cover',
                                                    borderRadius: 2,
                                                }}
                                            />
                                        </Box>
                                    </Grid>

                                    {/* Details Section - REFINED & CONDITIONAL */}
                                    <Grid size={{ xs: 12, md: isFullscreen ? 2.5 : 4 }} sx={{ height: { xs: '50%', md: '100%' }, overflowY: 'auto', bgcolor: 'background.paper', borderLeft: '1px solid', borderColor: 'divider' }}>
                                        <Box sx={{ p: 4, display: 'flex', flexDirection: 'column', gap: 3 }}>

                                            {/* Design Number */}
                                            <Box sx={{ pb: 2, borderBottom: '1px solid', borderColor: 'divider' }}>
                                                <Typography variant="overline" color="text.secondary" fontWeight={600} sx={{ letterSpacing: 1.5 }}>
                                                    DESIGN NO
                                                </Typography>
                                                <Typography variant="h5" fontWeight="600" color="#2c2c2c" sx={{ mt: 0.5 }}>
                                                    {prod.designno || "N/A"}
                                                </Typography>
                                            </Box>

                                            {/* Weights */}
                                            <Box>
                                                <Typography variant="subtitle2" color="text.secondary" fontWeight={600} gutterBottom sx={{ mb: 2 }}>
                                                    WEIGHT DETAILS
                                                </Typography>
                                                <Grid container spacing={2}>
                                                    {prod.MetalWeight > 0 && (
                                                        <Grid size={{ xs: 6 }}>
                                                            <Box>
                                                                <Typography variant="caption" display="block" color="text.disabled">Net Weight</Typography>
                                                                <Typography variant="body1" fontWeight={500}>{prod.MetalWeight}g</Typography>
                                                            </Box>
                                                        </Grid>
                                                    )}
                                                    {prod.ActualGrossweight > 0 && (
                                                        <Grid size={{ xs: 6 }}>
                                                            <Box>
                                                                <Typography variant="caption" display="block" color="text.disabled">Gross Weight</Typography>
                                                                <Typography variant="body1" fontWeight={500}>{prod.ActualGrossweight}g</Typography>
                                                            </Box>
                                                        </Grid>
                                                    )}
                                                </Grid>
                                            </Box>

                                            {/* Specifications (Conditional) */}
                                            {(pMetal || pDiamonds || pStones) && (
                                                <Box sx={{ mt: 1 }}>
                                                    <Typography variant="subtitle2" color="text.secondary" fontWeight={600} gutterBottom sx={{ mb: 2 }}>
                                                        SPECIFICATIONS
                                                    </Typography>
                                                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>

                                                        {/* Metal Type & Color Row (50-50 Split) */}
                                                        {(prod.metaltype || prod.metalcolor) && (
                                                            <Box sx={{ display: 'flex', width: '100%', alignItems: 'flex-start' }}>
                                                                {/* Metal Type - 50% */}
                                                                <Box sx={{ width: '50%', pr: 1 }}>
                                                                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                                                        <Typography variant="body2" color="text.disabled">Metal Type</Typography>
                                                                        <Typography variant="body2" fontWeight={500} color="secondary.main">{prod.metaltype}</Typography>
                                                                    </Box>
                                                                </Box>

                                                                {/* Divider or Spacer could go here, but 50-50 implies direct split */}

                                                                {/* Metal Color - 50% */}
                                                                <Box sx={{ width: '50%', pl: 1, borderLeft: '1px solid #e0e0e0' }}>
                                                                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                                                        <Typography variant="body2" color="text.disabled">Metal Color</Typography>
                                                                        <Typography variant="body2" fontWeight={500} color="secondary.main">{prod.metalcolor}</Typography>
                                                                    </Box>
                                                                </Box>
                                                            </Box>
                                                        )}

                                                        {/* Purity Row */}
                                                        {prod.metalpurity && (
                                                            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                                                <Typography variant="body2" color="text.disabled">Purity</Typography>
                                                                <Typography variant="body2" fontWeight={500} color="secondary.main">
                                                                    {prod.metalpurity}
                                                                </Typography>
                                                            </Box>
                                                        )}
                                                        {/* Stones Row (50-50 Split) */}
                                                        <Box sx={{ display: 'flex', width: '100%', alignItems: 'flex-start' }}>
                                                            {pDiamonds && (
                                                                <Box sx={{ width: '50%', pr: 1 }}>
                                                                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                                                        <Typography variant="body2" color="text.disabled">Diamond</Typography>
                                                                        <Typography variant="body2" fontWeight={500} color="secondary.main">{prod.diamondpcs || 0} pcs</Typography>
                                                                    </Box>
                                                                </Box>
                                                            )}
                                                            {pStones && (
                                                                <Box sx={{ width: '50%', pl: 1, borderLeft: '1px solid #e0e0e0' }}>
                                                                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                                                        <Typography variant="body2" color="text.disabled">Stone</Typography>
                                                                        <Typography variant="body2" fontWeight={500} color="secondary.main">{prod.stonepcs || 0} pcs</Typography>
                                                                    </Box>
                                                                </Box>
                                                            )}
                                                        </Box>
                                                    </Box>
                                                </Box>
                                            )}

                                            {/* Product Info (Category, Brand, etc) */}
                                            {hasAdditionalInfo && (
                                                <Box sx={{ mt: 1 }}>
                                                    <Typography variant="subtitle2" color="text.secondary" fontWeight={600} gutterBottom sx={{ mb: 2 }}>
                                                        ADDITIONAL INFO
                                                    </Typography>
                                                    <Grid container spacing={2}>
                                                        {prod.brandname && (
                                                            <Grid size={{ xs: 6 }}>
                                                                <Typography variant="caption" color="text.disabled" display="block">Brand</Typography>
                                                                <Typography variant="body2" fontWeight={500} color="secondary.main">{prod.brandname}</Typography>
                                                            </Grid>
                                                        )}
                                                        {prod.collectionname && (
                                                            <Grid size={{ xs: 6 }}>
                                                                <Typography variant="caption" color="text.disabled" display="block">Collection</Typography>
                                                                <Typography variant="body2" fontWeight={500} color="secondary.main">{prod.collectionname}</Typography>
                                                            </Grid>
                                                        )}
                                                        {prod.categoryname && (
                                                            <Grid size={{ xs: 6 }}>
                                                                <Typography variant="caption" color="text.disabled" display="block">Category</Typography>
                                                                <Typography variant="body2" fontWeight={500} color="secondary.main">{prod.categoryname}</Typography>
                                                            </Grid>
                                                        )}
                                                        {prod.subcategoryname && (
                                                            <Grid size={{ xs: 6 }}>
                                                                <Typography variant="caption" color="text.disabled" display="block">Sub Category</Typography>
                                                                <Typography variant="body2" fontWeight={500} color="secondary.main">{prod.subcategoryname}</Typography>
                                                            </Grid>
                                                        )}
                                                        {prod.producttype && (
                                                            <Grid size={{ xs: 6 }}>
                                                                <Typography variant="caption" color="text.disabled" display="block">Product Type</Typography>
                                                                <Typography variant="body2" fontWeight={500} color="secondary.main">{prod.producttype}</Typography>
                                                            </Grid>
                                                        )}
                                                        {prod.stylename && (
                                                            <Grid size={{ xs: 6 }}>
                                                                <Typography variant="caption" color="text.disabled" display="block">Style</Typography>
                                                                <Typography variant="body2" fontWeight={500} color="secondary.main">{prod.stylename}</Typography>
                                                            </Grid>
                                                        )}
                                                        {prod.gendername && (
                                                            <Grid size={{ xs: 6 }}>
                                                                <Typography variant="caption" color="text.disabled" display="block">Gender</Typography>
                                                                <Typography variant="body2" fontWeight={500} color="secondary.main">{prod.gendername}</Typography>
                                                            </Grid>
                                                        )}
                                                    </Grid>
                                                </Box>
                                            )}

                                        </Box>
                                    </Grid>
                                </Grid>
                            </SwiperSlide>
                        );
                    })}
                </Swiper>
            </DialogContent>

            <DialogActions sx={{ p: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: 'background.paper', borderTop: '1px solid', borderColor: 'divider' }}>

                {/* Left Area: Secondary Actions */}
                <Box sx={{ display: 'flex', gap: 1, flex: 1 }}>
                    {onSearchSimilar && (currentProd?.originalUrl || currentProd?.image || currentProd?.thumbUrl) && (
                        <Button
                            variant="outlined"
                            startIcon={<ScanSearch size={18} />}
                            onClick={() => {
                                onSearchSimilar(currentProd);
                                onClose();
                            }}
                            sx={softPrimaryButtonSx}
                        >
                            Search Similar
                        </Button>
                    )}
                    {fromCart && (
                        <Button
                            variant="outlined"
                            color="error"
                            startIcon={<Trash2 size={18} />}
                            onClick={handleRemoveItem}
                            sx={softDangerButtonSx}
                        >
                            Remove
                        </Button>
                    )}
                </Box>

                {/* Center Area: Navigation Controls */}
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flex: 1, justifyContent: 'center' }}>
                    <IconButton
                        onClick={() => swiperRef?.slidePrev()}
                        disabled={activeIndex === 0}
                        sx={{
                            ...sliderButton,
                            opacity: activeIndex === 0 ? 0.5 : 1
                        }}
                    >
                        <ChevronLeft size={24} />
                    </IconButton>

                    <Typography variant="body2" sx={{ fontWeight: 600, minWidth: '60px', textAlign: 'center', color: 'secondary.dark' }}>
                        {activeIndex + 1} / {sliderProducts.length}
                    </Typography>

                    <IconButton
                        onClick={() => swiperRef?.slideNext()}
                        disabled={activeIndex === sliderProducts.length - 1}
                        sx={{
                            ...sliderButton,
                            opacity: activeIndex === sliderProducts.length - 1 ? 0.5 : 1
                        }}
                    >
                        <ChevronRight size={24} />
                    </IconButton>
                </Box>

                {/* Right Area: Primary Action */}
                <Box sx={{ display: 'flex', gap: 2, flex: 1, justifyContent: 'flex-end' }}>
                    <Button
                        variant="contained"
                        startIcon={<ShoppingCart size={18} />}
                        onClick={() => {
                            if (!isItemInCart(currentProd.id)) {
                                onAddToCart(currentProd);
                            }
                        }}
                        disabled={isItemInCart(currentProd?.id)}
                        sx={{
                            ...softPrimaryButtonSx,
                            bgcolor: isItemInCart(currentProd?.id) ? 'action.disabledBackground' : 'primary.main',
                            color: isItemInCart(currentProd?.id) ? 'text.disabled' : 'common.white',
                            '&:hover': {
                                bgcolor: isItemInCart(currentProd?.id) ? 'action.disabledBackground' : 'primary.dark',
                            }
                        }}
                    >
                        {isItemInCart(currentProd?.id) ? 'In Cart' : 'Add to Cart'}
                    </Button>
                </Box>
            </DialogActions>
            <ReusableConfirmModal
                open={openConfirmModal}
                onClose={() => setOpenConfirmModal(false)}
                onConfirm={handleConfirmRemove}
                type="removeItem"
            />
        </Dialog>
    );
}