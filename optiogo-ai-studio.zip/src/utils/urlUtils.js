export const isFrontendFeRoute = () => {
    return typeof window !== "undefined" && sessionStorage.getItem("urlParamsFlag")?.toLowerCase() === "fe";
};
