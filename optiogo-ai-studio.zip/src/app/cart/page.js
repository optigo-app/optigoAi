import CartPageMUI from '@/components/Cart/CartComponent'
import React from 'react'

const page = () => {
  return (
    <CartPageMUI />
  )
}

export default page